

(*  val enleve : string -> string
renvoie le mot sans les guillemets s'il y en avait *)
let enleve mot = 
  let debut = String.get mot 0 and fin = String.get mot ((String.length mot)-1) in
  if (debut!= '"' && fin!='"') then mot 
  else String.sub mot 1 ((String.length mot)-2)
;; 

(* val mot : string -> string -> int -> string
renvoie le string compris entre le debut de la chaine et la prochaine virgule (seulement si celle-ci n'est pas entre guillemets) *)
let rec mot chaine result bin = match chaine with 
  |""-> result
  |_-> let debut = String.get chaine 0 in
       let suite = String.sub chaine 1 ((String.length chaine)-1) in
       let new_bin = if (debut!='"') then bin else (bin+1) mod 2 in
       let debut2 = if (debut!='\'') then debut else ' ' in
       if (bin!=1) then 
       if debut2=',' then result
       else mot suite (result^(Char.escaped debut2)) new_bin
       else mot suite (result^(Char.escaped debut2)) new_bin
;;

(* val decoupe_chaine : string -> string list
 renvoie la chaine découpée, à partir du séprateur virgule *)
let rec decoupe_chaine chaine = match chaine with
  |""-> []
  |_ -> let mot1 = mot chaine "" 0 in
	let taille = String.length mot1 in
	let suite = (if (taille!=(String.length chaine)) 
	  then  (String.sub chaine (taille+1) ((String.length chaine)-(taille+1)))
	  else (String.sub chaine taille ((String.length chaine)-taille)))
        in
	(enleve mot1)::(decoupe_chaine suite)
;;

exception Nb_invalide;;


(* val valeur : 'a list -> int -> 'a
renvoie la valeur qui est à la nb ieme place *)
let rec valeur list nb = match list with
  |[]-> raise Nb_invalide
  |e::q -> if (nb==1) then e else valeur q (nb-1)
;;

let list = ("un"::"deux"::"trois"::"quatre"::[]);;
valeur list 4;;

(* val trans : string list -> string * string * string * string
transforme la liste en couple *)
let trans list =
if ((List.length list)==4) 
then ((valeur list 1),(valeur list 2),(valeur list 3),(valeur list 4))
else ((valeur list 1),(valeur list 2),(valeur list 3),"")
;;

let list2 = ("un"::"deux"::"trois"::[]);;
trans list2;;

(* val convert : 'a * 'b * 'c * 'd -> 'a * 'b * 'c
renvoie un tuple de 3 *)
let convert (a,b,c,_) = (a,b,c) ;;
convert (trans list);;




(* question c
renvoie le titre des livres publiés en 2012*)
let rec qc book = match book with
  |[]->[]
  |(_,title,_,x)::q-> if (x<>"2012") then (qc q) else title::(qc q)
;;



(* val isbn : 'a -> ('b * 'a * 'c * 'd) list -> 'b
recupère l'ISBN du livre dont le titre est t *)
let rec isbn title book = match book with
  |[]->raise Not_found
  |(is,t,_,_)::q-> if (t<>title) then isbn title q else is
;;


(* val copyNo : 'a -> ('b * 'a * 'c) list -> 'b list
récupère la liste des copyNo du livre d'ISBN x *)
let rec copyNo x bookCopy = match bookCopy with
  |[]->[]
  |(coNo,is,_)::q->if (is<>x) then (copyNo x q) else coNo::(copyNo x q)
;;



(* bookLoanX : 'a -> ('a * 'b * 'c * 'd) list -> ('a * 'b * 'c * 'd) list
récupère la liste des bookLoan du livre de copyNo x*)
let rec bookLoanX x bookLoan = match bookLoan with
  |[]->[]
  |(a,b,c,d)::q-> if (x<>a) then (bookLoanX x q) else (a,b,c,d)::(bookLoanX x q)
;;

(* val cnavailable : 'a -> 'b -> ('c * 'a * 'a * 'd) list -> bool
renvoie true si le livre de copyNo x est dosponible à la date date *)
let rec cnavailable date x bookLoanX = match bookLoanX with
  |[]->true
  |(a,b,c,_)::q->if (date<b || date>c) then (cnavailable date x q)
    else false
;;


(*  val lavailable : 'a -> 'b list -> ('b * 'a * 'a * 'c) list -> 'b list
renvoie la liste des livres de copyNo de bookcopyX qui sont disponible à la date date *)
let rec lavailable date bookCopyX bookLoan = match bookCopyX with
  |[]->[]
  |a::q -> let blX = (bookLoanX a bookLoan) in
	   if (not (cnavailable date a blX))
	   then (lavailable date q bookLoan)
	   else a::(lavailable date q bookLoan)
;;



(* question e
 val qe :
  'a ->
  'b ->
  ('c * 'b * 'd * 'e) list ->
  ('f * 'c * 'g) list -> ('f * 'a * 'a * 'h) list -> 'f list
date correspond à la date d'auj, x est le titre du livre, et book, bookCopy bookLoan sont les listes contenant les valeurs des fichiers csv
renvoie les livres de titre x qui sont disponibles pour emprunt a la date date *)
let qe date x book bookCopy bookLoan =
  let is=(isbn x book) in
  let cn=(copyNo is bookCopy) in
  (lavailable date cn bookLoan)
;;



(* val bnoavailable : 'a -> 'b -> ('b * 'a * 'a * 'c) list -> 'c lis
le borrowerNo actuel du livre de  copyNo x à la date date*)
let rec bnoavailable date x bookLoanx = match bookLoanx with
  |[]->[]
  |(a,b,c,d)::q->if ((a=x) && (date>=b && date<=c)) then d::(bnoavailable date x q)
    else (bnoavailable date x q)
;;

(* val borrowerX : 'a -> ('a * 'b * 'c) list -> 'b 
 le nom du borrower de borrowerNo x*)
let rec borrowerX x borrower = match borrower with
  |[]-> raise Not_found
  |(a,b,_)::q-> if (a<>x) then borrowerX x q else b
;;

(*  val concat : 'a list -> 'a list -> 'a list
concatène les listes l1 et l2 *)
let rec concat l1 l2 = match l1 with
  |[]->l2
  |a::q -> concat q (a::l2);;


(* val borower_aux : 'a list -> ('a * 'b * 'c) list -> 'b list
renvoie la liste des noms associés au borrowerNo de la liste bno *)
let rec borower_aux bno borrower = match bno with
	  |[] -> []
	  |e::t -> (borrowerX e borrower)::(borower_aux t borrower)
	  
;;

(* val borower :
  'a -> 'b list -> ('c * 'd * 'e) list -> ('b * 'a * 'a * 'c) list -> 'd list
renvoie la liste des noms des borrower ayant un livre de titre de x à la date date *)
let rec borower date bookCopyX borrower bookLoan  = match bookCopyX with
  |[]->[]
  |a::q-> let bno = (bnoavailable date a bookLoan) in
	  concat (borower_aux bno borrower) (borower date q borrower bookLoan)
;;

(* question f 
   val qf :
  'a ->
  'b ->
  ('c * 'd * 'e) list ->
  ('c * 'a * 'a * 'f) list ->
  ('d * 'b * 'g * 'h) list -> ('f * 'i * 'j) list -> 'i list
renvoie la liste des noms des borrower ayant en leur possession un livre de titre x a la date date *)
let qf date x bookCopy bookLoan book borrower =

  let is=(isbn x book) in
  let cn=(copyNo is bookCopy) in
  (borower date cn borrower bookLoan)
;;


(* val actuelbn : 'a -> ('b * 'a * 'a * 'c) list -> 'c list
renvoie la liste de tous les borrowerNo qui ont actuellement un livre *)
let rec actuelbn date bookLoan = match bookLoan with
  |[]->[]
  |(a,b,c,d)::q-> if (date>=b && date<=c) then d::(actuelbn date q)
    else (actuelbn date q)
;;

(* val presentb : 'a list -> ('a * 'b * 'c) list -> 'b list
renvoie la liste des noms des borrowers ayant son borrowernNo dans actuelborrower  *)
let rec presentb actuelborrower borrower = match actuelborrower with
  |[]-> []
  |a::q -> (borrowerX a borrower)::(presentb q borrower)
;;

(* val qg : 'a -> ('b * 'a * 'a * 'c) list -> ('c * 'd * 'e) list -> 'd list
 renvoie les noms des borrower ayant un livre en possession a la date date *)
let qg date bookLoan borrower =
  let abn = (actuelbn date bookLoan) in (presentb abn borrower);;


(* val print_list : string list -> unit
affiche les valeurs de la liste l *)
let rec print_list l = match l with
|[]-> ()
|e::q -> print_string e; print_string "\n"; print_list q
;;


(* val ouvrir4 : string -> (string * string * string * string) list
 renvoie les valeurs contenues dans le fichier *)
let ouvrir4 fichier = 
  let op = open_in fichier in 
    let rec lire op result = try
      let line = decoupe_chaine (input_line op) in 
      let line2 =  trans line in
	lire op (line2::result) 
 with End_of_file -> result
in
(lire op [])
;;

(* val ouvrir3 : string -> (string * string * string) list
 renvoie les valeurs contenues dans le fichier *)
let ouvrir3 fichier = 
  let op = open_in fichier in 
    let rec lire op result = try
      let line = decoupe_chaine (input_line op) in 
      let line2 =  convert (trans line) in
	lire op (line2::result) 
 with End_of_file -> result
in
(lire op [])
;;


exception Not_file;;

(* fonction principale permettant de répondre aux question c, e, f et g *)
let main() =  
try
      if (Array.length Sys.argv < 5 || Array.length Sys.argv >= 6 ) 
      then raise Not_file 
      else
  let book = ouvrir4 Sys.argv.(1) in
  let bookCopy = ouvrir3 Sys.argv.(2) in
  let borrower = ouvrir3  Sys.argv.(3) in
  let bookLoan = ouvrir4 Sys.argv.(4) in
  let () = print_string "Quelle est la date d'aujourd'hui ? " in 
  let date = read_line() in
  let () = print_string "Quelle question voulez-vous poser ? (c/e/f/g) " in
  let quest = read_line() in
  match quest with
  |"c"-> let fct1 = qc book in 
	 if (fct1==[]) then print_string "Aucun ! \n" 
	 else print_list fct1
  |"e"-> let () = print_string "Quelle est le titre en question ? " in
	 let title1 = read_line() in
	 let fct2 = qe date title1 book bookCopy bookLoan in 
	 if (fct2==[]) then print_string "Aucun ! \n" 
	 else  print_list fct2 
  |"f"->  let () = print_string "Quelle est le titre en question ? " in
	  let title2 = read_line() in
	  let fct3 = qf date title2 bookCopy bookLoan book borrower in 
	  if (fct3==[]) then print_string "Aucun ! \n" 
	  else print_list fct3
  |"g"-> let fct4 = (qg date bookLoan borrower) in 
	 if (fct4==[]) then print_string "Aucun ! \n" 
	 else  print_list fct4
	  |_-> raise Not_file
	    
 with Not_file -> print_string ("usage : "^Sys.argv.(0)^" book bookCopy borrower bookLoan\n")
;;



main();;

